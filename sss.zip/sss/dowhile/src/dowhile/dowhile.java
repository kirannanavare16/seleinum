package dowhile;

public class dowhile 
{

	public static void main(String[] args)
	{
		int j = 30;
		do
		{
			System.out.print(j+ " ");
			j=j-3;
		}
		while(j<=30);
	}

}
