public class Pattern
{
	public static void main(String[] args)
	{
	 char ch = 'A';
	 for(int i = 1; i<=4; i++)
	  {
		 for(int j = 1; j<=i; j++)
		 {
			 if(i%2!=0)
				 System.out.print(ch++);
			 else
			 {
				 char s = (char) (ch+32);
				 System.out.print(s);
				 ch++;
			 }
		 }
		 System.out.println();
	  }
	}
}
