public class Patern
{
	public static void main(String[] args)
	{
		for(int i =4; i>=1; i--)
		{
			for(int k = i; k<4; k++)
			{
				System.out.print(" ");
			}
			for(int j = i; j>=1; j--)
			{
				System.out.print(j);
			}
			for(int s = 2; s<=i; s++)
			{
				System.out.print(s);
			}
			System.out.println();
		}
		for(int i =2; i<=4; i++)
		{
			for(int k = i; k<4; k++)
			{
				System.out.print(" ");
			}
			for(int j = i; j>=1; j--)
			{
				System.out.print(j);
			}
			int a =2;
			for(int s = i; s>1; s--)
			{
				System.out.print(a);
				a++;
			}
			System.out.println();
		}
	}
}
