package Exception;
import java.util.Scanner;
class TooYoungException extends RuntimeException
{
  TooYoungException(String s)  //This is a constructor
  {
   super(s);  //This is a method
  }
}
   
class TooOldException extends RuntimeException
{
  TooOldException(String s) //This is a constructor
   {
   super(s);  //This is a method
   }
}

class c
{
 public static void main(String[] args)
  {
    Scanner scn=new Scanner(System.in);
    System.out.println("Enter your age: ");
    int age=scn.nextInt();
    if(age<21)
      throw new TooYoungException("please wait for some time");
    else
    {  
      if(age>65)
        throw new TooOldException("already crossed your age");
       else
    	   System.out.println("You are eligible");
    }
  }
}

