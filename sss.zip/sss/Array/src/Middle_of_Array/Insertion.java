package Middle_of_Array;
import java.util.Scanner;

public class Insertion
{
	public static void main(String[] args)
	{
		int[] a = {8,10,12,14,16,18,20};
		System.out.print("Before Inserting Value: ");
		for(int i : a)
		{
			System.out.print(i+" ");
		}
		System.out.println();
		Scanner scn = new Scanner(System.in);
		System.out.print("Enter Integer Value:");
		int n = scn.nextInt();
		System.out.print("Enter Position:");
		int m = scn.nextInt();
		int[] b = new int[a.length+1];
		for(int i=0; i<b.length;i++)
		{
			if(i<=m)
			{
				if(i==m)
			    	b[i]=n;
				else
				    b[i]=a[i];
			}
			else
				b[i]=a[i-1];
		}
		System.out.print("After Inserting Value: ");
		for(int i=0; i<b.length; i++)
		{
			System.out.print(b[i]+" ");
		}
	}
}
