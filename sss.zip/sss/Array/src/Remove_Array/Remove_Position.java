package Remove_Array;
import java.util.*;
public class Remove_Position 
{
	public static void main(String[] args)
	{
		int[] a = {10,54,8,13,24,81,5,19};
		System.out.println("Before Removal: ");
		for(int i : a)
		{
			System.out.print(i + " ");
		}
		System.out.println();
		Scanner scn = new Scanner(System.in);
		System.out.print("Enter Position To Remove From 0 to "+ (a.length-1)+":");
		int n = scn.nextInt();
		int[] b = new int[a.length-1];
		for(int i =0; i<a.length; i++)
		{
			if(i<=n)
			{
				if(i==n)
				{}
				else
				b[i]=a[i];
			}
			else
				b[i-1]=a[i];
		}
		System.out.println("After Removal: ");
		for(int i = 0; i<b.length; i++)
		{
			System.out.print(b[i]+" ");
		}
	}
}
