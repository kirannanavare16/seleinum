package Replace_Value;
import java.util.Scanner;

public class Replace
{
	public static void main(String[] args) 
	{
		int[] a = {10,54,8,13,24,81,5,19};
		System.out.print("Before Replacing Value:");
		for(int i : a)
		{
			System.out.print(i+ " ");
		}
		System.out.println();
		Scanner scn = new Scanner(System.in);
		System.out.print("Enter Value From Above Array To Replace: ");
		int n = scn.nextInt();
		System.out.print("Enter New Value: ");
		int m = scn.nextInt();
		for(int i=0; i<a.length;i++)
		{
			if(a[i]==n)
			{
				a[i]=m;
			}
		}
		System.out.print("After Replacing Value:");
		for(int i : a)
			System.out.print(i+ " ");
	}
}
