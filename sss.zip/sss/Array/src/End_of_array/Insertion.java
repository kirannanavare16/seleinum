package End_of_array;
import java.util.Scanner;

public class Insertion
{
	public static void main(String[] args)
	{
		int[] a = {8,10,12,14,16,18,20};
		Scanner scn = new Scanner(System.in);
		System.out.print("Enter Integer Value:");
		int n = scn.nextInt();
		int[] b = new int[a.length+1];
		b[b.length-1]=n;
		for(int i=0; i<a.length;i++)
		{
			b[i]=a[i];
		}
		System.out.println("Before Inserting Value:");
		for(int i=0; i<a.length;i++)
		{
			System.out.print(a[i]+" ");
		}
		System.out.println();
		System.out.println("After Inserting Value:");
		for(int i=0; i<b.length; i++)
		{
			System.out.print(b[i]+" ");
		}
	}
}
