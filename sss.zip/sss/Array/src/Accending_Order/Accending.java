package Accending_Order;

public class Accending 
{
	public static void main(String[] args) 
	{
		int[] a = {130,87,34,250,70,140,190,80};
		System.out.println("Before Arrange In Accending Order: ");
		for(int i : a)
		{
			System.out.print(i+" ");
		}
		System.out.println();
		for(int i=0; i<a.length; i++)
		{
			for(int j=0 ; j<a.length-1;j++)
			{
				if(a[j]>a[j+1])
				{
					int temp = a[j];
					a[j]=a[j+1];
					a[j+1]=temp;
				}
			}
		}
		System.out.println("After Arrange In Accending Order: ");
		for(int i : a)
			System.out.print(i+" ");
	}
}
