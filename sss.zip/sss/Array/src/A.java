import java.util.Scanner;

public class A
{
	public static void main(String[] args)
	{
		int[] a = {10,54,78,8,19};
		Scanner scn = new Scanner(System.in);
		System.out.print("Enter integer value:");
		int n = scn.nextInt();
		int[] b = new int[a.length+1];
		for(int i = 0; i<a.length; i++)
		{
			b[i] = a[i];
		}
		b[b.length-1] = n;
		System.out.println("Before inserting value:");
		for(int i =0; i<a.length; i++)
		{
			System.out.print(a[i] + " ");
		}
			System.out.println();
		System.out.println("After inserting value:");
		for(int i =0; i<b.length; i++)
		{
			System.out.print(b[i] + " ");
		}

	}

}
