
public class Practice
{
	String Name;
	int roll;
	int id;
	public String toString()  //override object class toString method
	{
		return Name + " : " + roll + " : " + hashCode();//call hashCode method
	}
	public int hashCode() //override object class hashCode method
	{
		id=1000;
		id = id+2;
		return id;
	}
	public Practice(String name, int rollno) //Constructor
	{
		Name = name;
		roll = rollno;
	}
	public static void main(String[] args)
	{
		Practice p = new Practice("Satyen" , 907);
		Practice p1 = new Practice("Kartiki" , 806);
		
		System.out.println(p);
		System.out.println(p1);
	}

}
