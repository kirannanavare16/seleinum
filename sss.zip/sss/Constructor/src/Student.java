public class Student
{
	String name;
	int rollno; 
	public Student(String name, int rollno) 
	{
		this.name = name;
		this.rollno = rollno;
	}

	public static void main(String[] args)
	{
		Student s1=new Student("Rohit" , 101);
		System.out.println(s1.name);
		System.out.println(s1.rollno);
		Student s2=new Student("Virat" , 102);
		System.out.println(s2.name);
		System.out.println(s2.rollno);
	}
}
