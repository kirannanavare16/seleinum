package Combine_toStringAnd_hashCode;

public class Student
{
	String Name;
	int roll;
	public String toString()  //override object class toString method
	{
		return Name + " : " + roll + " : " + hashCode();//call hashCode method
	}
	public int hashCode() //override object class hashCode method
	{
		return roll;
	}
	public Student(String name, int rollno) //Constructor
	{
		Name = name;
		roll = rollno;
	}
	public static void main(String[] args)
	{
		Student p = new Student("Satyen" , 907);
		Student p1 = new Student("Kartiki" , 806);
		
		System.out.println(p);
		System.out.println(p1);
	}

}