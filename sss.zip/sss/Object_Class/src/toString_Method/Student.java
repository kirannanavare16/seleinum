package toString_Method;

public class Student 
{
	String name;
	int rollno;
	public String toString()
	{
		return name + " : " + rollno;
	}
	public static void main(String[] args)
	{
		Student s = new Student();
		s.name = "Satyen";
		s.rollno=907;
		
		Student s1 = new Student();
		s1.name = "Kartz";
		s1.rollno= 806;
		
		System.out.println(s);
		System.out.println(s1);
	}

}
