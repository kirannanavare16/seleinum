import java.util.Scanner;

public class Insertion
{
	public static void main(String[] args)
	{
		int[] a = {10,54,78,8,19};
		Scanner scn = new Scanner(System.in);
		System.out.print("Enter integer value:");
		int n = scn.nextInt();
		int[] b = new int[a.length+1];
		for(int i = 0; i<a.length; i++)
		{
			b[0] = a[0];
			b[1] = a[1];
			b[2] = a[2];
			b[3] = n;
			b[4] = a[3];
			b[5] = a[4];
		}
		System.out.println("Before inserting value:");
		for(int i =0; i<a.length; i++)
		{
			System.out.print(a[i] + " ");
		}
			System.out.println();
		System.out.println("After inserting value:");
		for(int i =0; i<b.length; i++)
		{
			System.out.print(b[i] + " ");
		}

	}

}
