
public class Array   //Printing Max. Number
{
	public static void main(String[] args)
		{
		int[] a = {130,87,34,250,70,140,190,80};
		
		int max = 0;
		
		for(int i = 0 ; i<a.length ; i++)
		{
				if(max <a[i])
					max = a[i];
		}
		
		System.out.println(max);
	}
}
