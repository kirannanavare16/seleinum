package Getter_Setter;
import java.util.Scanner;

class Account
{
	private double Balance= 10000;
	public double getBalance(String userID, String password)
    {
		if(userID.equals("Rice@9075")&& password.equals("Wheat@9075"))
		    return Balance;
		else
			return 0;
	}
	public void setBalance(double Amount, int s) 
	{
		if(s==1) //For Deposit Of Amount To Account
		{
			Balance = Balance+ Amount;
			System.out.println("Your Updated Balance Is: "+Balance);
		}
		if(s==2) //For Withdraw Of Amount From Account
		{
			if(Amount<=Balance)
			{
				Balance = Balance - Amount;
				System.out.println("Your Updated Balance Is: "+Balance);
			}
			if(Amount>Balance)
				System.out.println("Sorry..!! You Have Insufficient Balance");
		}
	}
}

class Bank
{
	public static void main(String[] args)
	{
		System.out.println("Welcome To Cognition Bank");
		Account a = new Account();
		Scanner scn = new Scanner(System.in);
		System.out.print("Enter Your UserID: ");
		String userID = scn.next();
		System.out.print("Enter Your Password: ");
		String password = scn.next();
		double d = a.getBalance(userID, password);
		if(d==0)
			System.out.print("Please Enter Correct userID & Password");
		else
			System.out.println("Available Balance is: "+d);
		System.out.println();
		if(userID.equals("Rice@9075")&& password.equals("Wheat@9075"))
		{
		System.out.println("Choose Anyone From The Below Option: ");
		System.out.print("Choose 1 To Deposit & Choose 2 For Withdraw");
		int s = scn.nextInt();
		System.out.print("Please Enter Amount:");
		Double Amount = scn.nextDouble();
		a.setBalance(Amount, s);
		}
	}
}
